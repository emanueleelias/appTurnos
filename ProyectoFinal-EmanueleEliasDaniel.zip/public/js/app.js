import App from './clases/App.js';

//Iniciamos la app instanciando la clase App() y por ende ejecutando su constructor.
const app = new App();



